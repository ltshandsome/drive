#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUFFER_SIZE 1024 

int main(int argc, char *argv[]) {
    if (argc != 6) {
        printf("Usage: %s <input1> <input2> <input3> <input4> <output>\n", argv[0]);
        return 1;
    }

    int total_file_size = 0;
    FILE* input_files[4];
    for(int i = 0; i < 4; i++){
        input_files[i] = fopen(argv[i + 1], "rb"); 
        
        // store the file size
        fseek(input_files[i], 0, SEEK_END); 
        total_file_size += ftell(input_files[i]);
        rewind(input_files[i]);
    }
    FILE* output_file = fopen(argv[5], "wb"); 
    // store total file size in the beginning of the file
    fwrite(&total_file_size, sizeof(int), 1, output_file);

    char buffer[4][BUFFER_SIZE];
    char parity[BUFFER_SIZE];
    int max_bytes_read = 0;

    do{
        max_bytes_read = 0; // reinitialze
        for(int i = 0; i < 4; i++){
            //clear buffer
            for(int j = 0; j < BUFFER_SIZE; j++){
                buffer[i][j] = 0;
            }
            
            int bytes_read = fread(buffer[i], 1, BUFFER_SIZE, input_files[i]);
            if (bytes_read > max_bytes_read){
                max_bytes_read = bytes_read;
            }
        }

        for (int i = 0; i < max_bytes_read; i++) {
            parity[i] = 0;
            for(int j = 0; j < 4; j++){
                parity[i] ^= buffer[j][i];
            }
        }

        fwrite(parity, 1, max_bytes_read, output_file);
    } while(max_bytes_read);

    // close files
    for(int i = 0; i < 4; i++){
        fclose(input_files[i]);
    }
    fclose(output_file);
    return 0;
}
