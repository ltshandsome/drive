#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUFFER_SIZE 1024 

int main(int argc, char *argv[]) {
    if (argc != 6) {
        printf("Usage: %s <input1> <input2> <input3> <parity> <output>\n", argv[0]);
        return 1;
    }

    int total_file_size = 0;
    FILE* input_files[3];
    for(int i = 0; i < 3; i++){
            
        // store the file size
        fseek(input_files[i], 0, SEEK_END); 
        input_files[i] = fopen(argv[i + 1], "rb"); 
    }
    FILE* parity_file = fopen(argv[4], "rb");
    FILE* output_file = fopen(argv[5], "wb"); 

    char buffer[4][BUFFER_SIZE];
    char restore[BUFFER_SIZE];
    int max_bytes_read = 0;

    do{
        max_bytes_read = 0; // reinitialze
        for(int i = 0; i < 4; i++){
            //clear buffer
            for(int j = 0; j < BUFFER_SIZE; j++){
                buffer[i][j] = 0;
            }
            
            int bytes_read = fread(buffer[i], 1, BUFFER_SIZE, input_files[i]);
            if (bytes_read > max_bytes_read){
                max_bytes_read = bytes_read;
            }
        }

        for (int i = 0; i < max_bytes_read; i++) {
            restore[i] = 0;
            for(int j = 0; j < 4; j++){
                restore[i] ^= buffer[j][i];
            }
        }
        
        // TODO: if we delete A.bin (7 MiB), after restoring we will get a 10 MiB file with 3 MiB zeros in the end of file
        fwrite(restore, 1, max_bytes_read, output_file);  
    } while(max_bytes_read);

    // close files
    for(int i = 0; i < 4; i++){
        fclose(input_files[i]);
    }
    fclose(output_file);
    return 0;
}
